package com.ecart.jpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecart.jpa.entity.Buyer;
import com.ecart.jpa.entity.Cart;
import com.ecart.jpa.entity.PurchaseHistory;
import com.ecart.jpa.entity.Transactions;
import com.ecart.jpa.repository.BuyerRepository;
import com.ecart.jpa.repository.CartRepository;
import com.ecart.jpa.repository.ItemRepository;
import com.ecart.jpa.repository.PurchaseRepository;
import com.ecart.jpa.repository.TransactionRepository;

@Service
public class CartService {

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private PurchaseRepository purchaseRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private ItemRepository itemRepository;

	public Optional<Cart> addCartItem( Cart cartItem, Long buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
			cartItem.setBuyer(buyer);
			return cartRepository.save(cartItem);});
		//}).orElseThrow(() -> new ResourceNotFoundException("BuyerId " + buyerId + " not found"));
	}

	public Cart updateCartItem(Cart cart,Long cartId) {
		Optional<Cart> cartItem = cartRepository.findById(cartId);
		Cart b=null;
		if(cartItem.isPresent()) {
			b = cartItem.get();
			b.setQuantity(cart.getQuantity());
			b.setTotalPrice(cart.getTotalPrice());
			b.setPrice(cart.getPrice());
			
		return cartRepository.save(b); 
		}
		return null;
	}
	
	public String deleteCartItemById(Long cartId) {
		cartRepository.deleteById(cartId);
		return "Item with cartId "+cartId+" is deleted.";
	}
	
	public void emptyCart(Long buyerId) {
		
		cartRepository.emptyCart(buyerId);
	}
	
	public List<Cart> getAllCartItems(Long buyerId) {
		
		return cartRepository.getAllCartItems(buyerId);
	}

	public String checkOutCart(Transactions transaction, Long buyerId) {
	
		Buyer buyer=buyerRepository.getOne(buyerId);
		System.out.println(buyer);
		transaction.setBuyer(buyer);
		transactionRepository.save(transaction);
		List<Cart> cart=cartRepository.getAllCartItems(buyerId);
		for(int i=0;i<cart.size();i++) {
			PurchaseHistory purchaseHistory=new PurchaseHistory();
			Cart newCart=cart.get(i);
			int size=newCart.getQuantity();
			purchaseHistory.setNumberOfItems(size);
			purchaseHistory.setBuyer(buyer);
			cartRepository.deleteById(newCart.getCartId());
			purchaseRepository.save(purchaseHistory);
		}
		
		return null;
	}

	public ItemRepository getItemRepository() {
		return itemRepository;
	}

	public void setItemRepository(ItemRepository itemRepository) {
		this.itemRepository = itemRepository;
	}
}

