import { Component, OnInit } from '@angular/core';
import { Transactions, Cart, ViewCart } from '../items';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  constructor(private displaycart:ProductService) { }

  transcation:Transactions;
  transactionType:String;
  price:number;
  totalPrice:number;
  cart:Cart=new Cart();
  
  ngOnInit(): void {
  }

  Checkout(){
    console.log();
    this.transcation =new Transactions();
    this.transcation.price=this.price;
    this.transcation.totalAmount=this.totalPrice;
   this.displaycart.CheckoutCart(this.transcation).subscribe(newview => this.transcation=newview);
   }
}
